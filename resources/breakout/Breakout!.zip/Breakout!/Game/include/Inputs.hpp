#ifndef INPUTS_HPP
#define INPUTS_HPP
/**
 * Inputs are represented only as numbers within this game. However, this
 * enumerator makes the inputs being used more explicit.
 * */
enum Inputs {
    Left = 0,
    Right,
    Start
};
#endif