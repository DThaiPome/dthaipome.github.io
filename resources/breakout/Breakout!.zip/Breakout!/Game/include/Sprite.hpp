#ifndef SPRITE_HPP
#define SPRITE_HPP
#include <SDL2/SDL.h>
#include <string.h>
/**
 * A wrapper class containing data for rendering a spritesheet.
 * */
class Sprite {
public:
    /**
	 * Create a sprite sheet.
     * 
     * @param spriteSheet the surface to use, provided by the resource manager.
     * @param frames the number of frames in this sheet.
     * @param width the width of this sprite, in pixels.
     * @param height the height of this sprite, in pixels.
	 * */
    Sprite(SDL_Surface* spriteSheet, unsigned int frames, unsigned int width, unsigned int height, SDL_Renderer* ren);
    /**
	 * Deletes the sprite sheet from memory.
	 * */
    ~Sprite();

    /**
	 * Render this frame of the sprite sheet at this location using this renderer.
     * 
     * @param ren the renderer.
     * @param frame the frame to use.
     * @param xPos the x coordinate, in pixels, to render the sprite at.
     * @param yPos the y coordinate, in pixels, to render the sprite at.
     * @param width the width to render it at (can be different than stored width).
     * @param height the height to render it at (can be different than stored width).
	 * */
    void renderAt(SDL_Renderer* ren, unsigned int frame, int xPos, int yPos, int width, int height);
    /**
     * Identical to other render function, but defaults to stored width and height.
     * */
    void renderAt(SDL_Renderer* ren, unsigned int frame, int xPos, int yPos);

private:
    unsigned int frames, width, height;
    SDL_Surface* spriteSheet;
    SDL_Texture* texture;
    SDL_Rect src, dest;
};
#endif