#ifndef GAMEOBJECT_H
#define GAMEOBJECT_H
#include <SDL2/SDL.h>
#include "TinyMath.hpp"
/**
 * Abstract class - represents a game object that can be initialized, updated, and rendered.
 * */
class GameObject {
public:
    /**
     * Initialize position and dimensions to default values.
     * */
    GameObject();
    /**
     * No behaviour
     * */
    virtual ~GameObject();
    
    /**
     * Get this game object's position.
     * */
    Vector3D getPosition() const;
    /**
     * Get this game object's width.
     * */
    unsigned int getWidth() const;
    /**
     * Get this game object's height.
     * */
    unsigned int getHeight() const;
    
    /**
     * Initialize this game object.
     * */
    virtual void init() = 0;
    /**
     * Update this game object.
     * 
     * @param deltaTime pass in how much time has passed since the last
     * update.
     * */
    virtual void update(float deltaTime) = 0;
    /**
     * Render this game object.
     * 
     * @param ren the renderer to use.
     * */
    virtual void render(SDL_Renderer* ren) = 0;
protected:
    /**
     * This game object's position, in pixels.
     * */
    Vector3D position;
    /**
     * This game object's dimensions, in pixels.
     * */
    unsigned int width, height;
};
#endif