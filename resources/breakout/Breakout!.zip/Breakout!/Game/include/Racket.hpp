#ifndef RACKET_HPP
#define RACKET_HPP
#include <SDL2/SDL.h>
#include "GameObject.hpp"
#include "InputManager.hpp"
/**
 * Behaviour for the paddle object (I tried calling this "paddle" but the compiler
 * did not find this tasty so ... oh well I guess)
 * */
class Racket: public GameObject {
public:
    /**
     * No behaviour.
     * */
    Racket();
    /**
     * No behaviour.
     * */
    virtual ~Racket();

    /**
     * Initialize this object's position and dimensions.
     * */
    virtual void init();
    /**
     * Move left or right based on user input.
     * */
    virtual void update(float deltaTime);
    /**
     * Render the paddle (white rectangle).
     * */
    virtual void render(SDL_Renderer* ren);
private:
    SDL_Rect rect{};
    InputManager* input;
};
#endif