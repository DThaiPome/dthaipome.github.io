#ifndef RESOURCE_MANAGER_HPP
#define RESOURCE_MANAGER_HPP

#include <utility>
#include <map>
#include <vector>
#include <string>
#include <memory>
#include <iterator>
#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_mixer.h>
#include "Sprite.hpp"
#include "LevelData.hpp"

/**
 * Loads and unloads all game resources, including sprites, sounds,
 * fonts, and level and language data.
 * */
class ResourceManager{
public:
	/**
     * Shut down this manager if it is still initialized.
     * */
	~ResourceManager();

	/**
     * Get a singleton instance of this manager.
     * */
	static ResourceManager* getInstance();

	/**
     * Initialize this manager.
     * */
	void init();

	/**
     * Get the sprite at this path. Allocates memory for this sprite if none
	 * already exists.
	 * 
	 * @param imagePath file path to this sprite.
	 * @param frames number of frames within the sprite sheet.
	 * @param width width of the image.
	 * @param height height of the image.
     * */
	Sprite* loadSprite(std::string imagePath, int frames, int width, int height, SDL_Renderer* ren);
	/**
     * Get the font at this path. Allocates memory for this font if none
	 * already exists.
	 * 
	 * @param fontPath file path to this font.
	 * @param size size to load the font at. Loading one font at different
	 * font sizes is supported.
     * */
	TTF_Font* loadFont(std::string fontPath, unsigned int size);
	/**
     * Get the sound at this path. Allocates memory for this sound if none
	 * already exists.
	 * 
	 * @param soundPath file path to the sound.
     * */
	Mix_Chunk* loadSound(std::string soundPath);

	/**
     * Get the music at this path. Allocates memory for this music if none
	 * already exists.
	 * 
	 * @param musicPath file path to the sound.
     * */
	Mix_Music* loadMusic(std::string musicPath);

	/**
     * Load the levels from this file path into the manager, for later access.
	 * 
	 * @param folderPath path to folder containing level text data.
     * */
	void loadLevelsFrom(std::string folderPath);
	/**
	 * Retrieve the data for this level.
	 * 
	 * @param levelIndex id for the level, determined by the order in which
	 * the level was loaded into the game.
     * */
	const LevelData & loadLevel(unsigned int levelIndex);
	/**
     * Retrieve the total count of loaded levels.
     * */
	unsigned int getLevelCount();

	/**
     * Set this manager to use the language data contained at this file path.
	 * 
	 * @param languagePath file path to language data.
     * */
	bool loadLanguage(std::string languagePath);
	/**
     * Get the string with this id from the currently loaded language.
	 * 
	 * @param id string id for this phrase, as specified in the text data.
     * */
	const std::string & getPhrase(std::string id);

	/**
     * Sets a global renderer to be freely accessed and used by any objects.
	 * 
	 * @param ren renderer to use.
     * */
	void setGlobalRenderer(SDL_Renderer* ren);
	/**
	 * Get the global renderer.
	 * */
	SDL_Renderer* getGlobalRenderer();

	/**
	 * Shut down this manager.
	 * */
	void shutdown();

private:
	ResourceManager();
	static ResourceManager* instance;
    ResourceManager(ResourceManager const&); // Avoid copy constructor
    void operator=(ResourceManager const&); // Don't allow assignment.
	bool initialized{false};
	
	std::map<std::string, Sprite*> sprites;
	std::map<std::string, TTF_Font*> fonts;
	std::map<std::string, Mix_Chunk*> sounds;
	std::map<std::string, Mix_Music*> musics;

	SDL_Renderer* globalRenderer;

	unsigned int levelCount;
	// Row count, data
	std::vector<LevelData> levelData;
	bool** initData(unsigned int width, unsigned int height);
	void deleteData(bool** data, unsigned int height);

	std::map<std::string, std::string> language;
};
#endif
