#ifndef TEXTOBJECT_HPP
#define TEXTOBJECT_HPP
#include "GameObject.hpp"
#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <string>
#include "TinyMath.hpp"
/**
 * A game object that holds and displays text.
 * */
class TextObject: public GameObject {
public:
    /**
	 * Frees any memory used.
	 * */
    virtual ~TextObject();

    /**
	 * Sets the font to use, using the global renderer.
	 * */
    void setFont(TTF_Font* font);
    /**
	 * Set the position of this text.
	 * */
    void setPosition(const Vector3D & position);
    /**
     * Set the text to display.
     * */
    void setText(const std::string & text);

    /**
	 * Initialize this object's position and width to default values.
	 * */
    virtual void init();
    /**
	 * No behaviour.
	 * */
    virtual void update(float deltaTime);
    /**
	 * Render the text with this renderer.
	 * */
    virtual void render(SDL_Renderer* ren);
private:
    void freeTextures();

    TTF_Font* font;
    SDL_Surface* surface{};
    SDL_Texture* texture{};
    SDL_Rect rect{};
    SDL_Renderer* renderer;
    std::string text;
};
#endif