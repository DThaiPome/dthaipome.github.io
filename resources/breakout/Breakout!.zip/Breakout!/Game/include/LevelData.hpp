#ifndef LEVELDATA_HPP
#define LEVELDATA_HPP
/**
 * Stores data on how to construct a single level. Boolean array represents
 * which locations have bricks and which don't.
 * */
struct LevelData {
    unsigned int width;
    unsigned int height;
    bool** data;
};
#endif