#ifndef ENTITYMANAGER_HPP
#define ENTITYMANAGER_HPP
#include <string>
#include <map>
#include <vector>
#include "GameObject.hpp"
/**
 * Initializes, updates, and renders all objects in the game. Also retains ownership over
 * all memory allocated for game objects.
 * */
class EntityManager {
public:
    /**
     * Shutdown if still initialized.
     * */
    ~EntityManager();
    /**
     * Get a singleton instance of this manager.
     * */
    static EntityManager* getInstance();

    /**
     * Initialize manager.
     * */
    void init();
    /**
     * Initialize all game objects currently in the game.
     * */
    void initAll();
    //This implementation needs to be here so it links properly.
    /**
     * Add a game obejct to the game. The type of game object is specified
     * by the type argument. Also specify if the object should be updated
     * and rendered. Returns the name used to refer to this object.
     * */
    template<typename GObject>
    std::string addObject(std::string name, bool updateThis, bool renderThis) {
        if (this->gameObjectMap[name]) {
            name += std::to_string(++cloneCount);
            name = this->addObject<GObject>(name, updateThis, renderThis);
            return name;
        }
        GameObject* obj = new GObject();
        this->gameObjectMap[name] = obj;
        if (updateThis) {
            this->updateObjects.push_back(obj);
        }
        if (renderThis) {
            this->renderObjects.push_back(obj);
        }
        obj->init();
        return name;
    }
    /**
     * Get the game object associated with this name.
     * */
    GameObject* getObject(std::string name);
    /**
     * Delete the game object associated with this name.
     * */
    void deleteObject(std::string name);
    /**
     * Update all game objects.
     * */
    void updateAll(float deltaTime);
    /**
     * Render all game objects.
     * */
    void renderAll(SDL_Renderer* ren);
    /**
     * Delete all game objects, free all memory, and shut down.
     * */
    void shutdown();
private:
    EntityManager();
    static EntityManager* instance;
    static unsigned int cloneCount;
    bool initialized{false};
    std::map<std::string, GameObject*> gameObjectMap;
    std::vector<GameObject*> updateObjects;
    std::vector<GameObject*> renderObjects;
};
#endif