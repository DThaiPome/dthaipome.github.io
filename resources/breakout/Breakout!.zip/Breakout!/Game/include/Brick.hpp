#ifndef BRICK_HPP
#define BRICK_HPP
#include <SDL2/SDL.h>
#include "GameObject.hpp"
#include "BallCollisions.hpp"
#include "Ball.hpp"
/**
 * Game and rendering behaviour for brick objects.
 * */
class Brick: public GameObject {
public:
    /**
     * No behaviour.
     * */
    virtual ~Brick();

    /**
     * Initialize the dimensions and position.
     * */
    virtual void init();
    /**
     * No behaviour.
     * */
    virtual void update(float deltaTime);
    /**
     * Render the brick rectangle (yellow rectangle)
     * */
    virtual void render(SDL_Renderer* ren);

    /**
     * Move the brick to a new position.
     * */
    void setPosition(const Vector3D & pos);
    /**
     * Return the type of collision this brick is making with the ball (can be
     * BallCollision::None)
     * */
    BallContact checkCollisionWithBall(Ball* ball);
private:
    SDL_Rect rect{};
};
#endif