#ifndef LEVELMANAGER_HPP
#define LEVELMANAGER_HPP
#include <vector>
#include <utility>
#include <string>
#include "Brick.hpp"
#include "EntityManager.hpp"
#include "BallCollisions.hpp"
#include "Ball.hpp"
#include "Racket.hpp"
#include "TextObject.hpp"
#include <SDL2/SDL_ttf.h>
/**
 * Stores global information for the current level being played, and loads
 * and unloads levels.
 * */
class LevelManager {
public:
    /**
     * Shut down this manager if it is still initialized.
     * */
    ~LevelManager();
    /**
     * Get a singleton instance of this manager.
     * */
    static LevelManager* getInstance();
    
    /**
     * Check if any bricks have collided with the ball.
     * */
    BallContact checkBrickCollisions(Ball* ball);

    /**
     * Display the victory message and load the next level.
     * */
    void winLevel();
    /**
     * Display the loss message and re-load the current level.
     * */
    void loseLevel();
    /**
     * Subtract a life, and LOSE if there are no more lives left. Otherwise,
     * reset the ball and paddle.
     * */
    void missBall();
    /**
     * Add 30 points to the score.
     * */
    void brickBroken();

    /**
     * Check to see if objects should be updating.
     * */
    bool isGameActive();
    /**
     * Check to see if the player has won the level.
     * */
    bool isLevelWon();

    /**
     * Create game objects necessary for the level, initialize text, and
     * load the first level.
     * */
    void init();
    /**
     * Await a START input if the game is paused.
     * */
    void update(float deltaTime);
    /**
     * Shut down this manager.
     * */
    void shutdown();
private:
    LevelManager();
    static LevelManager* instance;
    bool initialized{false};

    void startLevel();
    void deleteBricks();
    void initBricks();
    Vector3D brickPosition(Brick* brick, unsigned int i, unsigned int j);

    void setLives(unsigned int lives);
    void setScore(unsigned int score);

    void setMessageText(std::string text);

    bool gameActive, levelWon, gameOver;
    unsigned int lives;
    unsigned int width, height, brickCount, score, currentLevel;
    std::vector<std::pair<std::string, Brick*>> bricks;
    bool** locations;
    EntityManager* entities;
    InputManager* input;
    Racket* paddle;
    Ball* ball;
    TextObject* livesText;
    TextObject* scoreText;
    TextObject* messageText;
    TTF_Font* font;

    Mix_Music* music;
};
#endif