#ifndef BALLCOLLISIONS_HPP
#define BALLCOLLISIONS_HPP
#include <cmath>

/**
 * Represents how the ball collided with something.
 * */
enum BallCollisions {
    None = 0,
    Vertical,
    Horizontal,
    Paddle,
    Miss
};

/**
 * Stores data for a single collision. Sorted in a list by largest to smallest
 * penetration.
 * */
struct BallContact {
    BallCollisions type;
    float penetration;
    float distance;
    bool operator<(const BallContact & lhs) const {
        return abs(penetration) > abs(lhs.penetration);
    }
};
#endif