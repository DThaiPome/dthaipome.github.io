#include <SDL2/SDL.h>
#ifndef TICKTIMER_HPP
#define TICKTIMER_HPP
/**
 * Uses the SDL timer to keep track of how much time has passed.
 * */
class TickTimer {
public:
	/**
	 * Start the timer at 0.
	 * */
	TickTimer();
	/**
	 * No behaviour.
	 * */
	~TickTimer();

	/**
	 * Return how much time has passed since the timie was last started, 
	 * in milliseconds.
	 * */
	Uint32 get_ticks();
	/**
	 * Start the timer from 0 again.
	 * */
	void restart();
private:
	Uint32 m_startTime;
};
#endif
