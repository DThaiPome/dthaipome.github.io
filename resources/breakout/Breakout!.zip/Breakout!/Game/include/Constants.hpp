#ifndef CONSTANTS_HPP
#define CONSTANTS_HPP

#define WINDOW_WIDTH 1280
#define WINDOW_HEIGHT 720

#define PADDLE_SPEED 250
#define BALL_INITIAL_SPEED 300

#define BRICK_SPACING 5
#define BRICK_TOP_PADDING 80

#define YES_BRICK_CHAR 'B'
#define NO_BRICK_CHAR 'X'

#endif