#ifndef INPUTMANAGER_HPP
#define INPUTMANAGER_HPP

#include <map>

/**
 * A global manager for determining which inputs are active.
 * */
class InputManager {
public:
    /**
     * Shutdown, if this has not already been shut down.
     * */
    ~InputManager();

    /**
     * Get a singleton instance of this manager.
     * */
    static InputManager* getInstance();

    /**
     * Initialize this manager.
     * */
    void init();
    /**
     * Create an input with the given id.
     * */
    void initInput(unsigned int id);
    /**
     * Mark the input with this id as down (true) or up (false).
     * */
    void setInputDown(unsigned int id, bool inputDown);
    /**
     * Check if this input is down.
     * */
    bool getInputDown(unsigned int id);
    /**
     * Shut down this manager.
     * */
    void shutdown();

private:
    InputManager();

    bool initialized{false};
    static InputManager* instance;
    std::map<unsigned int, bool> inputsDown;
};
#endif