#ifndef BALL_HPP
#define BALL_HPP
#include "GameObject.hpp"
#include "BallCollisions.hpp"
#include <SDL2/SDL_mixer.h>

/**
 * Game and rendering behaviour for the ball object.
 * */
class Ball: public GameObject {
public:
    /**
     * No behaviour.
     * */
    Ball();
    /**
     * No behaviour.
     * */
    virtual ~Ball();

    /**
     * Set the dimensions and position of the ball, and initialize other data.
     * */
    virtual void init();
    /**
     * Move at the proper direction and speed every frame. Speed is in pixels/sec.
     * Also check for collisions with the walls, the paddle, and the bricks.
     * */
    virtual void update(float deltaTime);
    /**
     * Render the ball rect (white square)
     * */
    virtual void render(SDL_Renderer* ren);
private:
    BallContact checkForWallCollision();
    BallContact checkForPaddleCollision();
    // Collide against something besides the paddle
    void normalCollide(BallContact contact);
    // Collide against paddle
    void paddleCollide(BallContact contact);

    Vector3D direction;
    float speed;
    GameObject* paddle;
    Mix_Chunk* hitPaddleSound;
    Mix_Chunk* hitBrickSound;
    SDL_Rect rect{};
};
#endif