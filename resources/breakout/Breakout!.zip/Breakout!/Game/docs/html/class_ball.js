var class_ball =
[
    [ "Ball", "class_ball.html#a86a144d3dad6c953e422e32435923bbb", null ],
    [ "~Ball", "class_ball.html#a78aa1f06b39fc9f81df82bef399c475c", null ],
    [ "init", "class_ball.html#a22be7789e682843ce50840323e8e88b5", null ],
    [ "render", "class_ball.html#a31f06f452e4f6859d22b5545d7022cae", null ],
    [ "update", "class_ball.html#afac1524953a92f40780f4ce36ca989ec", null ]
];