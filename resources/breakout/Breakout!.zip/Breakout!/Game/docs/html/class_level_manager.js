var class_level_manager =
[
    [ "~LevelManager", "class_level_manager.html#a72ca9c27cc6b85143e20f83c520d1215", null ],
    [ "brickBroken", "class_level_manager.html#a2cdfa9da44a1b05ffd03f62c244a3bbf", null ],
    [ "checkBrickCollisions", "class_level_manager.html#ac0f03e182a0bbd3e83df38cf58466e1d", null ],
    [ "init", "class_level_manager.html#a13d561519bb3765a55a7f8ce811bbf72", null ],
    [ "isGameActive", "class_level_manager.html#a201e9515d6c1a07daf2c4d44ac83cab5", null ],
    [ "isLevelWon", "class_level_manager.html#ad930f0e34a5663000ca2da7f54aace91", null ],
    [ "loseLevel", "class_level_manager.html#a1e5debbf2c7901568648e2b37dd678ad", null ],
    [ "missBall", "class_level_manager.html#adaaa567ff2cd33e17a54188d8e8dabdf", null ],
    [ "shutdown", "class_level_manager.html#aadc5e9780ea5d38bcc0a858b53ce3572", null ],
    [ "update", "class_level_manager.html#a6b3fd9a1cf088dc17d59ff2ef5b3f7b0", null ],
    [ "winLevel", "class_level_manager.html#a307f06aca9f49c39974b115476d17c33", null ]
];