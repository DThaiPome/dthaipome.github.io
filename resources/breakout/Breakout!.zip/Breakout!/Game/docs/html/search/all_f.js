var searchData=
[
  ['width_56',['width',['../class_game_object.html#ade95bb86cc216d745edf8ea15101f2af',1,'GameObject']]],
  ['winlevel_57',['winLevel',['../class_level_manager.html#a307f06aca9f49c39974b115476d17c33',1,'LevelManager']]]
];
