var indexSectionsWithContent =
{
  0: "abcdegilmprstuvw~",
  1: "begilmrstv",
  2: "abcdgilmrstuw~",
  3: "pw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Variables"
};

