var searchData=
[
  ['winlevel_129',['winLevel',['../class_level_manager.html#a307f06aca9f49c39974b115476d17c33',1,'LevelManager']]]
];
