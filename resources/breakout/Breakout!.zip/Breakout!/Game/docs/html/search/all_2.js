var searchData=
[
  ['checkbrickcollisions_5',['checkBrickCollisions',['../class_level_manager.html#ac0f03e182a0bbd3e83df38cf58466e1d',1,'LevelManager']]],
  ['checkcollisionwithball_6',['checkCollisionWithBall',['../class_brick.html#abc891c51ffb8e9f0dc7899cb5ea93663',1,'Brick']]]
];
