var searchData=
[
  ['textobject_51',['TextObject',['../class_text_object.html',1,'']]],
  ['ticktimer_52',['TickTimer',['../class_tick_timer.html',1,'TickTimer'],['../class_tick_timer.html#ad4342451b5947dccb12e20449355ca10',1,'TickTimer::TickTimer()']]]
];
