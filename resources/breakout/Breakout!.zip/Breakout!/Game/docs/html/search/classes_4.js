var searchData=
[
  ['leveldata_75',['LevelData',['../struct_level_data.html',1,'']]],
  ['levelmanager_76',['LevelManager',['../class_level_manager.html',1,'']]]
];
