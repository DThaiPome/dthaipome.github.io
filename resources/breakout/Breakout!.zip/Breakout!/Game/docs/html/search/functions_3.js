var searchData=
[
  ['deleteobject_89',['deleteObject',['../class_entity_manager.html#a5be250140805b24e7fd0ded9305df38f',1,'EntityManager']]]
];
