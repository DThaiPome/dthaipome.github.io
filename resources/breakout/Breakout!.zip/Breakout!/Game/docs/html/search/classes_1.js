var searchData=
[
  ['entitymanager_72',['EntityManager',['../class_entity_manager.html',1,'']]]
];
