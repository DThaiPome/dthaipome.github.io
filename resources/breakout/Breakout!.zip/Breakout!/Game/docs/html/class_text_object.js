var class_text_object =
[
    [ "~TextObject", "class_text_object.html#a83ce20001b26e0307f95c3a9392f7677", null ],
    [ "init", "class_text_object.html#a3a91f52101d7ed45e162521c56127ae3", null ],
    [ "render", "class_text_object.html#accd33b1b14a047f09bedf0b22cde578a", null ],
    [ "setFont", "class_text_object.html#a663ee275c3f92b7382d00a86194da105", null ],
    [ "setPosition", "class_text_object.html#a6dcf62a9c26d9821921d4cf332cc62cc", null ],
    [ "setText", "class_text_object.html#a0d195bd8b59147bf87948a7e518338f6", null ],
    [ "update", "class_text_object.html#a9f60f1e7bcc8f16315b698cb69b997cb", null ]
];