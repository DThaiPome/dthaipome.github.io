var class_brick =
[
    [ "~Brick", "class_brick.html#a8e1f06c7d5ba84454515f016c907098c", null ],
    [ "checkCollisionWithBall", "class_brick.html#abc891c51ffb8e9f0dc7899cb5ea93663", null ],
    [ "init", "class_brick.html#a59253d19f1f397c87f5c585a01b85eec", null ],
    [ "render", "class_brick.html#aa3e99f9d4311ec18d0112c07cc7e6971", null ],
    [ "setPosition", "class_brick.html#afb0e5e684487711a9ecb4bedc907301a", null ],
    [ "update", "class_brick.html#a5b9f0b7df34e0bae61d8a6e072ce2c2d", null ]
];