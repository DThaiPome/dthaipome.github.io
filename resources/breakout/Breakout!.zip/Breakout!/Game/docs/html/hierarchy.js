var hierarchy =
[
    [ "BallContact", "struct_ball_contact.html", null ],
    [ "EntityManager", "class_entity_manager.html", null ],
    [ "GameObject", "class_game_object.html", [
      [ "Ball", "class_ball.html", null ],
      [ "Brick", "class_brick.html", null ],
      [ "Racket", "class_racket.html", null ],
      [ "TextObject", "class_text_object.html", null ]
    ] ],
    [ "InputManager", "class_input_manager.html", null ],
    [ "LevelData", "struct_level_data.html", null ],
    [ "LevelManager", "class_level_manager.html", null ],
    [ "Matrix3D", "struct_matrix3_d.html", null ],
    [ "ResourceManager", "class_resource_manager.html", null ],
    [ "Sprite", "class_sprite.html", null ],
    [ "TickTimer", "class_tick_timer.html", null ],
    [ "Vector3D", "struct_vector3_d.html", null ]
];