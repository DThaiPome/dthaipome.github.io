var class_resource_manager =
[
    [ "~ResourceManager", "class_resource_manager.html#a671c186e4630599e7e36d000c53eaf80", null ],
    [ "getGlobalRenderer", "class_resource_manager.html#a6cf5b4c3a2c95047ee4fd89356fe84e5", null ],
    [ "getLevelCount", "class_resource_manager.html#a0f5f4b1e4735c5d4302a85b5a47de5a8", null ],
    [ "getPhrase", "class_resource_manager.html#ab1f9a2df387d3196d87603b0383b92d1", null ],
    [ "init", "class_resource_manager.html#a361b0f5b37615ef759ff6e345a63f616", null ],
    [ "loadFont", "class_resource_manager.html#ac01966ebf6a3f6bf96ca860c842f9ad6", null ],
    [ "loadLanguage", "class_resource_manager.html#a1e9eb152fc94dbb37760139277634d56", null ],
    [ "loadLevel", "class_resource_manager.html#a375eb78571939bc52bd162e9131c3866", null ],
    [ "loadLevelsFrom", "class_resource_manager.html#a33ffe077a5a22014ab9e6fdbc02ea68f", null ],
    [ "loadSound", "class_resource_manager.html#affc6ad6b4067dc2b9523d5fd3813f545", null ],
    [ "loadSprite", "class_resource_manager.html#a3658c208e9076730a6631507f4f2d0a6", null ],
    [ "setGlobalRenderer", "class_resource_manager.html#af877faaf5e572b4d856bb10847d72492", null ],
    [ "shutdown", "class_resource_manager.html#a4f37986f5f3ee7927477a002a17466f5", null ]
];