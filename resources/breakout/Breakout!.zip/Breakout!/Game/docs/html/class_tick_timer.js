var class_tick_timer =
[
    [ "TickTimer", "class_tick_timer.html#ad4342451b5947dccb12e20449355ca10", null ],
    [ "~TickTimer", "class_tick_timer.html#acde5a6c4f6602d9c4dbdf9fc5112a6b9", null ],
    [ "get_ticks", "class_tick_timer.html#ad5ac8878eb54a450a5455346cb662b59", null ],
    [ "restart", "class_tick_timer.html#a49a554b49e2b25efb4f49ea43644ba95", null ]
];