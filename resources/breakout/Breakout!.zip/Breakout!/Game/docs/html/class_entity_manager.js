var class_entity_manager =
[
    [ "~EntityManager", "class_entity_manager.html#a71a36c9fb8d579a1a1ec108e0fccf175", null ],
    [ "addObject", "class_entity_manager.html#a72fda40f89f29246d653125df6aba5c5", null ],
    [ "deleteObject", "class_entity_manager.html#a5be250140805b24e7fd0ded9305df38f", null ],
    [ "getObject", "class_entity_manager.html#a535f48771b211d3d969fdab07b771b43", null ],
    [ "init", "class_entity_manager.html#ae0abecb1a8037d6af51d950491115bfb", null ],
    [ "initAll", "class_entity_manager.html#a1836fea7d245277df3843f6a8f71e8e5", null ],
    [ "renderAll", "class_entity_manager.html#aac134d016b0d643560cc7bdf0a5a7118", null ],
    [ "shutdown", "class_entity_manager.html#a38bbb81e997e7adf2f8ecbb183355a0d", null ],
    [ "updateAll", "class_entity_manager.html#ab584c6d06258e4988dfa3805ad844282", null ]
];