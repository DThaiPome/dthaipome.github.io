var struct_level_data =
[
    [ "data", "struct_level_data.html#a50c8f2a6629a303e384314ff5b94184e", null ],
    [ "height", "struct_level_data.html#a38e6a5b3c4bfa7002a7f5551e8e1f5c1", null ],
    [ "width", "struct_level_data.html#a2e571434925785df1fa4eb8917a820bf", null ]
];