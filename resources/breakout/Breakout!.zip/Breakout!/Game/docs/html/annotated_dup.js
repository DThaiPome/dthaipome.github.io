var annotated_dup =
[
    [ "Ball", "class_ball.html", "class_ball" ],
    [ "BallContact", "struct_ball_contact.html", "struct_ball_contact" ],
    [ "Brick", "class_brick.html", "class_brick" ],
    [ "EntityManager", "class_entity_manager.html", "class_entity_manager" ],
    [ "GameObject", "class_game_object.html", "class_game_object" ],
    [ "InputManager", "class_input_manager.html", "class_input_manager" ],
    [ "LevelData", "struct_level_data.html", "struct_level_data" ],
    [ "LevelManager", "class_level_manager.html", "class_level_manager" ],
    [ "Matrix3D", "struct_matrix3_d.html", "struct_matrix3_d" ],
    [ "Racket", "class_racket.html", "class_racket" ],
    [ "ResourceManager", "class_resource_manager.html", "class_resource_manager" ],
    [ "Sprite", "class_sprite.html", "class_sprite" ],
    [ "TextObject", "class_text_object.html", "class_text_object" ],
    [ "TickTimer", "class_tick_timer.html", "class_tick_timer" ],
    [ "Vector3D", "struct_vector3_d.html", "struct_vector3_d" ]
];