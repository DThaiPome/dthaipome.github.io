var struct_ball_contact =
[
    [ "operator<", "struct_ball_contact.html#ad693ac582eeb2ce9758f3c179fa9ebaf", null ],
    [ "distance", "struct_ball_contact.html#a88df79cd552244a98a060c6268fdaef8", null ],
    [ "penetration", "struct_ball_contact.html#a2552b36056157719f2bee323758b83af", null ],
    [ "type", "struct_ball_contact.html#ac76cf7c70787281b5020cdd2352bfb48", null ]
];