var class_game_object =
[
    [ "GameObject", "class_game_object.html#a0348e3ee2e83d56eafca7a3547f432c4", null ],
    [ "~GameObject", "class_game_object.html#a224d4f6d9dd75c8a6f9d022eaf586fd9", null ],
    [ "getHeight", "class_game_object.html#a80baf5b4e767bedc944db58208d39222", null ],
    [ "getPosition", "class_game_object.html#a1844677273bb85513a260242a09069f1", null ],
    [ "getWidth", "class_game_object.html#a1cc2c65f9e979ff086ee31ef9b220437", null ],
    [ "init", "class_game_object.html#aa5cde72ad5bf24a20bc12180d34ec815", null ],
    [ "render", "class_game_object.html#aa436982cde9a0118ec738317d87afd9a", null ],
    [ "update", "class_game_object.html#ad2361258b2a53b82390b63b5ec6dd075", null ],
    [ "height", "class_game_object.html#a033b30bb7caf6660beabef5a81574bfb", null ],
    [ "position", "class_game_object.html#a133752839d0521018bf8e7aab7af98d9", null ],
    [ "width", "class_game_object.html#ade95bb86cc216d745edf8ea15101f2af", null ]
];