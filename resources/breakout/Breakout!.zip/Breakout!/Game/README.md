## Add any additional notes here

I did not get a chance to test the sound. A TA confirmed for me that it worked fine, but I unfortunately do not know how the volume is, so listen with caution :)

## Game Publicity

**Project Website**: https://dthaipome.github.io/projects/ge-breakout.html

## Compilation Instructions

Before compiling, ensure that the following packages are installed: libsdl2-dev, libsdl2-ttf-dev, libsdl2-mixer-dev

This project is built for Linux