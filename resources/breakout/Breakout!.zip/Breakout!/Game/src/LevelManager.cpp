#include "LevelManager.hpp"
#include "InputManager.hpp"
#include "Inputs.hpp"
#include <iostream>
#include <string>
#include "Ball.hpp"
#include "Racket.hpp"
#include "Constants.hpp"
#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include "ResourceManager.hpp"

LevelManager* LevelManager::instance = 0;

LevelManager::LevelManager() {}

LevelManager::~LevelManager() {
    if (this->initialized) {
        this->shutdown();
    }
    if (instance == this) {
        delete instance;
    }
}

LevelManager* LevelManager::getInstance() {
    if (!instance) {
        instance = new LevelManager();
    }
    return instance;
}

void LevelManager::winLevel() {
    this->setMessageText(ResourceManager::getInstance()->getPhrase("win"));
    this->currentLevel++;
    this->currentLevel %= ResourceManager::getInstance()->getLevelCount();
    this->startLevel();
    this->gameActive=false;
    this->gameOver = true;
}

void LevelManager::loseLevel() {
    this->setMessageText(ResourceManager::getInstance()->getPhrase("lose"));
    this->startLevel();
    this->gameActive=false;
    this->gameOver = true;
}

void LevelManager::setMessageText(std::string text) {
    this->messageText->setText(text);
    unsigned int width = this->messageText->getWidth();
    unsigned int height = this->messageText->getHeight();
    this->messageText->setPosition(Vector3D(
        WINDOW_WIDTH / 2 - width / 2,
        WINDOW_HEIGHT / 2 - height / 2
    ));
}

void LevelManager::missBall() {
    this->setLives(this->lives - 1);
    if (this->lives == 0) {
        this->loseLevel();
    } else {
        this->ball->init();
        this->paddle->init();
        this->gameActive=false;
    }
}

void LevelManager::setLives(unsigned int lives) {
    this->lives = lives;
    std::string liveStr = ResourceManager::getInstance()->getPhrase("lives");
    this->livesText->setText(liveStr + ": " + std::to_string(lives));
    this->livesText->setPosition(Vector3D(
        WINDOW_WIDTH - this->livesText->getWidth(),
        WINDOW_HEIGHT / 2
    ));
}

void LevelManager::setScore(unsigned int score) {
    this->score = score;
    std::string scoreStr = ResourceManager::getInstance()->getPhrase("score");
    this->scoreText->setText(scoreStr + ": " + std::to_string(score));
    this->scoreText->setPosition(Vector3D(
        0,
        WINDOW_HEIGHT / 2
    ));
}

void LevelManager::brickBroken() {
    this->brickCount--;
    this->setScore(this->score + 30);
    if (this->brickCount == 0) {
        this->winLevel();
    }
}

bool LevelManager::isGameActive() {
    return this->gameActive;
}

bool LevelManager::isLevelWon() {
    return this->levelWon;
}

void LevelManager::update(float deltaTime) {
    if (!(this->gameActive)) {
        if (this->input->getInputDown(Inputs::Start)) {
            if (this->gameOver) {
                this->gameOver = false;
                this->messageText->setText("");
                SDL_Delay(500);
            } else {
                this->gameActive = true;
            }
        }
    }
}

void LevelManager::init() {
    this->gameActive = false;
    this->gameOver = false;
    this->levelWon = false;

    this->entities = EntityManager::getInstance();
    this->input = InputManager::getInstance();

    // Add racket and ball and texts
    this->entities->addObject<Racket>("racket", true, true);
    this->entities->addObject<Ball>("ball", true, true);
    this->entities->addObject<TextObject>("lives", false, true);
    this->entities->addObject<TextObject>("score", false, true);
    this->entities->addObject<TextObject>("message", false, true);
    this->paddle = dynamic_cast<Racket*>(this->entities->getObject("racket"));
    this->ball = dynamic_cast<Ball*>(this->entities->getObject("ball"));
    this->livesText = dynamic_cast<TextObject*>(this->entities->getObject("lives"));
    this->scoreText = dynamic_cast<TextObject*>(this->entities->getObject("score"));
    this->messageText = dynamic_cast<TextObject*>(this->entities->getObject("message"));
    this->font = ResourceManager::getInstance()->loadFont("assets/fonts/DejaVuSansMono.ttf", 40);
    this->livesText->setFont(font);
    this->scoreText->setFont(font);
    this->messageText->setFont(font);
    
    // Add bricks
    ResourceManager::getInstance()->loadLevelsFrom("assets/levels/");
    LevelData firstLevel = ResourceManager::getInstance()->loadLevel(0);
    this->width = firstLevel.width;
    this->height = firstLevel.height;
    this->locations = firstLevel.data;
    this->bricks = std::vector<std::pair<std::string, Brick*>>();
    this->currentLevel = 0;
    this->startLevel();
    this->initialized = true;

    // Play music
    this->music = ResourceManager::getInstance()->loadMusic("assets/sounds/WFMGDMBLooped.wav");
    Mix_PlayMusic(this->music, -1);
}

Vector3D LevelManager::brickPosition(Brick* brick, unsigned int column, unsigned int row) {
    float rowLength = (brick->getWidth() + BRICK_SPACING) * this->width - BRICK_SPACING;
    float rowCenter = WINDOW_WIDTH / 2;
    float rowOrigin = rowCenter - (rowLength / 2);
    float x = (brick->getWidth() + BRICK_SPACING) * column + rowOrigin;
    float y = (brick->getHeight() + BRICK_SPACING) * row + BRICK_TOP_PADDING;
    return Vector3D(x, y);
}

void LevelManager::startLevel() {
    LevelData level = ResourceManager::getInstance()->loadLevel(this->currentLevel);
    this->width = level.width;
    this->height = level.height;
    this->locations = level.data;
    this->deleteBricks();
    this->initBricks();
    this->paddle->init();
    this->ball->init();
    this->setLives(3);
    this->setScore(0);
}

void LevelManager::initBricks() {
    this->brickCount = 0;
    for(int i = 0; i < this->height; i++) {
        for(int j = 0; j < this->width; j++) {
            if (locations[i][j]) {
                this->brickCount++;
                auto brickName = this->entities->addObject<Brick>("brick", false, true);
                Brick* brick = dynamic_cast<Brick*>(this->entities->getObject(brickName));
                brick->setPosition(this->brickPosition(brick, j, i));
                this->bricks.push_back({brickName, brick});
            }
        }
    }
}

void LevelManager::deleteBricks() {
    for(auto it = this->bricks.rbegin(); it != this->bricks.rend(); it++) {
        auto brickName = it->first;
        this->bricks.erase((it+1).base());
        this->entities->deleteObject(brickName);
    }
}

void LevelManager::shutdown() {
    Mix_HaltMusic();
    this->locations = nullptr;
    this->bricks.clear();
    this->initialized = false;
}

BallContact LevelManager::checkBrickCollisions(Ball* ball) {
    BallContact none{};
    for(auto it = this->bricks.begin(); it != this->bricks.end(); it++) {
        Brick* brick = it->second;
        BallContact contact = brick->checkCollisionWithBall(ball);
        if (contact.type != BallCollisions::None) {
            auto brickName = it->first;
            this->bricks.erase(it);
            this->entities->deleteObject(brickName);
            this->brickBroken();
            return contact;
        }
    }
    return none;
}