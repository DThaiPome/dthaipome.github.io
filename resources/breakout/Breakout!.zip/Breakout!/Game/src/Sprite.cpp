#include <SDL2/SDL.h>
#include <string.h>
#include "Sprite.hpp"

Sprite::Sprite(SDL_Surface* spriteSheet, unsigned int frames, unsigned int width, unsigned int height, SDL_Renderer* ren)
: spriteSheet(spriteSheet), frames(frames), width(width), height(height) {
    this->texture = SDL_CreateTextureFromSurface(ren, spriteSheet);
}

Sprite::~Sprite() {
    delete this->spriteSheet;
}

void Sprite::renderAt(SDL_Renderer* ren, unsigned int frame, int xPos, int yPos, int width, int height) {
    unsigned int srcFrame = frame % this->frames;

    this->src.x = srcFrame * this->width;
    this->src.y = 0;
    this->src.w = this->width;
    this->src.h = this->height;

    this->dest.x = xPos;
    this->dest.y = yPos;
    this->dest.w = width;
    this->dest.h = height;

    SDL_RenderCopy(ren, this->texture, &src, &dest);
}

void Sprite::renderAt(SDL_Renderer* ren, unsigned int frame, int xPos, int yPos) {
    this->renderAt(ren, frame, xPos, yPos, this->width, this->height);
}