#include "EntityManager.hpp"
#include <iostream>

EntityManager* EntityManager::instance = nullptr;
unsigned int EntityManager::cloneCount = 0;

EntityManager::EntityManager(){}
EntityManager::~EntityManager() {
    if (this->initialized) {
        this->shutdown();
    }
    if (instance == this) {
        delete instance;
    }
}

EntityManager* EntityManager::getInstance() {
    if (!instance) {
        instance = new EntityManager();
    }
    return instance;
}

void EntityManager::init() {
    this->gameObjectMap = std::map<std::string, GameObject*>();
    this->updateObjects = std::vector<GameObject*>();
    this->renderObjects = std::vector<GameObject*>();
    cloneCount = 0;
    this->initialized = true;
}

void EntityManager::shutdown() {
    for(auto it = this->gameObjectMap.begin(); it != this->gameObjectMap.end(); it++) {
        GameObject* obj = it->second;
        delete obj;
    }

    this->gameObjectMap.clear();
    this->updateObjects.clear();
    this->renderObjects.clear();
    this->initialized = false;
}

GameObject* EntityManager::getObject(std::string name) {
    if (this->gameObjectMap[name]) {
        return this->gameObjectMap[name];
    }
    return nullptr;
}

void EntityManager::deleteObject(std::string name) {
    if (this->gameObjectMap[name]) {
        GameObject* obj = this->gameObjectMap[name];
        for(auto it = this->updateObjects.begin(); it != this->updateObjects.end(); it++) {
            if (*it == obj) {
                this->updateObjects.erase(it);
                break;
            }
        }
        for(auto it = this->renderObjects.begin(); it != this->renderObjects.end(); it++) {
            if (*it == obj) {
                this->renderObjects.erase(it);
                break;
            }
        }
        this->gameObjectMap.erase(name);
        delete obj;
    }
}

void EntityManager::initAll() {
    for(auto it = this->gameObjectMap.begin(); it != this->gameObjectMap.end(); it++) {
        GameObject* obj = it->second;
        obj->init();
    }
}

void EntityManager::updateAll(float deltaTime) {
    for(auto it = this->updateObjects.begin(); it != this->updateObjects.end(); it++) {
        GameObject* obj = *it;
        obj->update(deltaTime);
    }
}

void EntityManager::renderAll(SDL_Renderer* ren) {
    for(auto it = this->renderObjects.begin(); it != this->renderObjects.end(); it++) {
        GameObject* obj = *it;
        obj->render(ren);
    }
}