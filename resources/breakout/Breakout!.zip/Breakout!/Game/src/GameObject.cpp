#include "GameObject.hpp"

GameObject::GameObject() : position(Vector3D(0, 0, 0)), width(0), height(0) {}
GameObject::~GameObject() {}

Vector3D GameObject::getPosition() const {
    return Vector3D(this->position.x, this->position.y, this->position.z);
}

unsigned int GameObject::getWidth() const {
    return this->width;
}

unsigned int GameObject::getHeight() const {
    return this->height;
}