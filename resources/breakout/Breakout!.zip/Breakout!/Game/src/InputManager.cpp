#include "InputManager.hpp"

InputManager* InputManager::instance = nullptr;

InputManager::InputManager() {}
InputManager::~InputManager() {
    if (this->initialized) {
        this->shutdown();
    }
    if (instance == this) {
        delete instance;
    }
}

InputManager* InputManager::getInstance() {
    if (!instance) {
        instance = new InputManager();
    }
    return instance;
}

void InputManager::init() {
    this->initialized = true;
    this->inputsDown = std::map<unsigned int, bool>();
}

void InputManager::initInput(unsigned int id) {
    this->inputsDown[id] = false;
}

void InputManager::setInputDown(unsigned int id, bool inputDown) {
    if (this->inputsDown.find(id) != this->inputsDown.end()) {
        this->inputsDown[id] = inputDown;
    }
}

bool InputManager::getInputDown(unsigned int id) {
    if (this->inputsDown.find(id) != this->inputsDown.end()) {
        return this->inputsDown[id];
    }
    return false;
}

void InputManager::shutdown() {
    this->inputsDown.clear();
    this->initialized = false;
}