#include "Brick.hpp"
#include <iostream>
#include "TinyMath.hpp"
#include <cmath>
#include <algorithm>
#include <vector>

Brick::~Brick() {}

void Brick::init() {
    this->position = Vector3D(0, 0);
    this->width = 80;
    this->height = 30;

    this->rect.x = this->position.x;
    this->rect.y = this->position.y;
    this->rect.w = this->width;
    this->rect.h = this->height;
}

void Brick::update(float deltaTime) {}

void Brick::render(SDL_Renderer* ren) {
    this->rect.x = this->position.x;
    this->rect.y = this->position.y;
    SDL_SetRenderDrawColor(ren, 0xFF, 0xFF, 0x00, 0xFF);
    SDL_RenderFillRect(ren, &(this->rect));
}

void Brick::setPosition(const Vector3D & pos) {
    this->position = Vector3D(pos.x, pos.y, pos.z);
}

BallContact Brick::checkCollisionWithBall(Ball* ball) {
    float brickLeft = this->position.x;
    float brickTop = this->position.y;
    float brickRight = brickLeft + this->width;
    float brickBottom = brickTop + this->height;

    float ballLeft = ball->getPosition().x;
    float ballTop = ball->getPosition().y;
    float ballRight = ballLeft + ball->getWidth();
    float ballBottom = ballTop + ball->getHeight();

    BallContact contact{};
    if (ballLeft >= brickRight) {
		return contact;
	}
	
	if (ballRight <= brickLeft) {
		return contact;
	}
	
	if (ballTop >= brickBottom) {
		return contact;
	}
	
	if (ballBottom <= brickTop) {
		return contact;
	}
    
    float rightPen = brickRight - ballLeft;
    float leftPen = brickLeft - ballRight;
    float topPen = brickTop - ballBottom;
    float bottomPen = brickBottom - ballTop;

    BallContact rightSide = {BallCollisions::Vertical, rightPen, 0};
    BallContact leftSide = {BallCollisions::Vertical, leftPen, 0};
    BallContact topSide = {BallCollisions::Horizontal, topPen, 0};
    BallContact bottomSide = {BallCollisions::Horizontal, bottomPen, 0};

    // Find the contact with minimum penetration
    BallContact contacts[] = {rightSide, leftSide, topSide, bottomSide};
    std::vector<BallContact> heap(contacts, contacts+4);
    std::make_heap(heap.begin(), heap.end());
    BallContact best = heap.front();
    return best;
}