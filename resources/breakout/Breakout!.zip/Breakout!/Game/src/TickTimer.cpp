#include "TickTimer.hpp"
#include <SDL2/SDL.h>
#include <stdlib.h>

TickTimer::TickTimer() : m_startTime(SDL_GetTicks()) {}

TickTimer::~TickTimer() {}

Uint32 TickTimer::get_ticks() {
	return SDL_GetTicks() - m_startTime;
}

void TickTimer::restart() {
	m_startTime = SDL_GetTicks();
}
