#include "Ball.hpp"
#include "Constants.hpp"
#include "EntityManager.hpp"
#include "LevelManager.hpp"
#include <SDL2/SDL_mixer.h>
#include "ResourceManager.hpp"

Ball::Ball() : GameObject() {}

Ball::~Ball() {}

void Ball::init() {
    this->width = 15;
    this->height = 15;
    this->position = Vector3D((WINDOW_WIDTH / 2) - (this->width / 2), 600);

    this->direction = Normalize(Vector3D(1, -1));
    this->speed = BALL_INITIAL_SPEED;

    this->rect.x = this->position.x;
    this->rect.y = this->position.y;
    this->rect.w = this->width;
    this->rect.h = this->height;

    this->paddle = EntityManager::getInstance()->getObject("racket");

    this->hitPaddleSound = ResourceManager::getInstance()->loadSound("./assets/sounds/PaddleHit.wav");
    this->hitBrickSound = ResourceManager::getInstance()->loadSound("./assets/sounds/BrickHit.wav");
}

void Ball::update(float deltaTime) {
    if (LevelManager::getInstance()->isGameActive()) {
        // Move
        this->direction = Normalize(this->direction);
        this->position += (this->direction * this->speed * deltaTime);

        // Collide with walls
        BallContact wallCollision = this->checkForWallCollision();
        if (wallCollision.type == BallCollisions::Miss) {
			Mix_PlayChannel(-1, this->hitPaddleSound, 0);
            LevelManager::getInstance()->missBall();
            return;
        }
        normalCollide(wallCollision);

        // Collide with paddle
        BallContact paddleCollision = checkForPaddleCollision();
        if (paddleCollision.type == BallCollisions::Paddle) {
			Mix_PlayChannel(-1, this->hitPaddleSound, 0);
            this->paddleCollide(paddleCollision);
        }

        // Collide with bricks
        BallContact brickCollision = LevelManager::getInstance()->checkBrickCollisions(this);
        if (brickCollision.type != BallCollisions::None) {
			Mix_PlayChannel(-1, this->hitBrickSound, 0);
            this->speed += 4;
        }
        normalCollide(brickCollision);
    }
}

void Ball::render(SDL_Renderer* ren) {
    this->rect.x = this->position.x;
    this->rect.y = this->position.y;

    SDL_SetRenderDrawColor(ren, 0xFF, 0xFF, 0xFF, 0xFF);
    SDL_RenderFillRect(ren, &(this->rect));
}

void Ball::paddleCollide(BallContact contact) {
    this->direction.y = -(this->direction.y);
    this->position.y += contact.penetration;

    this->direction.x = (2 * contact.distance) / this->paddle->getWidth();
}

BallContact Ball::checkForWallCollision() {
    float left = this->position.x;
    float top = this->position.y;
    float right = left + this->width;
    float bottom = top + this->height;

    BallContact contact{};

    if (left <= 0) {
        return {BallCollisions::Vertical, -left, 0};
    } else if (right >= WINDOW_WIDTH) {
        return {BallCollisions::Vertical, WINDOW_WIDTH - right, 0};
    }
    if (top <= 0) {
        return {BallCollisions::Horizontal, -top, 0};
    } else if (bottom >= WINDOW_HEIGHT) {
        return {BallCollisions::Miss, 0, 0};
    }
    return contact;
}

void Ball::normalCollide(BallContact contact) {
    if (contact.type == BallCollisions::Vertical) {
        this->direction = Vector3D(
            -(this->direction.x),
            this->direction.y
        );
        this->position.x += contact.penetration;
    } else if (contact.type == BallCollisions::Horizontal) {
        this->direction = Vector3D(
            this->direction.x,
            -(this->direction.y)
        );
        this->position.y += contact.penetration;
    }
}

BallContact Ball::checkForPaddleCollision() {
    float ballLeft = this->position.x;
    float ballTop = this->position.y;
    float ballRight = ballLeft + this->width;
    float ballBottom = ballTop + this->height;

    Vector3D paddlePos = this->paddle->getPosition();
    float paddleLeft = paddlePos.x;
    float paddleRight = paddleLeft + this->paddle->getWidth();
    float paddleTop = paddlePos.y;
    float paddleBottom = paddleTop + this->paddle->getHeight();

    BallContact contact{};

    if (ballLeft >= paddleRight) {
		return contact;
	}
	
	if (ballRight <= paddleLeft) {
		return contact;
	}
	
	if (ballTop >= paddleBottom) {
		return contact;
	}
	
	if (ballBottom <= paddleTop) {
		return contact;
	}

    contact.type = BallCollisions::Paddle;
    contact.penetration = paddleTop - ballBottom;
    float ballCenter = (ballLeft + ballRight) / 2;
    float paddleCenter = (paddleLeft + paddleRight) / 2;
    contact.distance = ballCenter - paddleCenter;

    return contact;
}