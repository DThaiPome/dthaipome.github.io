#include "TextObject.hpp"
#include <iostream>
#include "ResourceManager.hpp"

TextObject::~TextObject() {
    this->freeTextures();
}

void TextObject::freeTextures() {
    if (this->surface) {
        SDL_FreeSurface(this->surface);
    }
    if (this->texture) {
        SDL_DestroyTexture(this->texture);
    }
}

void TextObject::setFont(TTF_Font* font) {
    this->font = font;
    this->setText(this->text);
}

void TextObject::setPosition(const Vector3D & position) {
    this->position = position;
}

void TextObject::setText(const std::string & text) {
    this->freeTextures();

    this->text = text;
    this->surface = TTF_RenderText_Solid(this->font, text.c_str(), {0x99, 0x99, 0x99, 0xFF});
    this->texture = SDL_CreateTextureFromSurface(this->renderer, this->surface);
    int width, height;
    SDL_QueryTexture(this->texture, nullptr, nullptr, &width, &height);
    this->width = width;
    this->height = height;
}

void TextObject::init() {  
    this->text = " ";
    this->position = Vector3D(0, 0);
    this->width = 0;
    this->height = 0;
    this->renderer = ResourceManager::getInstance()->getGlobalRenderer();
}

void TextObject::update(float deltaTime) { }

void TextObject::render(SDL_Renderer* ren) {
    if (this->renderer != ResourceManager::getInstance()->getGlobalRenderer()) {
        this->renderer = ren;
        this->setText(this->text);
    }

    this->rect.w = width;
    this->rect.h = height;
    this->rect.x = this->position.x;
    this->rect.y = this->position.y;
    
    SDL_RenderCopy(this->renderer, this->texture, nullptr, &(this->rect));
}