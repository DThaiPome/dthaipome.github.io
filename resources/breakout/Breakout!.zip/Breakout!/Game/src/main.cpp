#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_mixer.h>
#include <string>
#include <iostream>
#include "Constants.hpp"
#include "InputManager.hpp"
#include "Inputs.hpp"
#include "EntityManager.hpp"
#include "LevelManager.hpp"
#include "TickTimer.hpp"
#include "ResourceManager.hpp"

int main(int argc, char** argv) {
    //Initialize SDL components
    SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO);
    TTF_Init();
    Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048);

    SDL_Window* window = SDL_CreateWindow("Breakout!", 0, 0, WINDOW_WIDTH, WINDOW_HEIGHT, SDL_WINDOW_SHOWN);
    SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);

    //Initialize input manager
    InputManager* input = InputManager::getInstance();
    input->init();
    
    // Left/Right input
    input->initInput(Inputs::Left);
    input->initInput(Inputs::Right);
    input->initInput(Inputs::Start);

    //Initialize resource manager
    ResourceManager* resources = ResourceManager::getInstance();
    resources->init();
    resources->setGlobalRenderer(renderer);

    //Load language
    if (argc == 2) {
        auto languageName = argv[1];
        std::string languagesRoot = "assets/languages/";
        std::string languagesSuffix = ".txt";
        if (!resources->loadLanguage(languagesRoot + languageName + languagesSuffix)) {
            resources->loadLanguage("assets/languages/english.txt");
        }
    } else {
        resources->loadLanguage("assets/languages/english.txt");
    }

    //Initialize entity manager
    EntityManager* entities = EntityManager::getInstance();
    entities->init();

    //Initialize level manager
    LevelManager* level = LevelManager::getInstance();
    level->init();

    //Init objects
    //entities->initAll();

    // FPS CAPPING
    const float TARGET_FPS = 60.0;
    const float TARGET_S = 1.0 / 60.0;
    const float TARGET_MS = TARGET_S * 1000.0;
    TickTimer frameCapTimer;

    //Game logic
    {
        bool running = true;

        while (running) {
            SDL_Event event;
            while (SDL_PollEvent(&event)) {
                if (event.type == SDL_QUIT) {
                    running = false;
                } else if (event.type == SDL_KEYDOWN) {
                    if (event.key.keysym.sym == SDLK_q) {
                        running = false;
                    } else if (
                    event.key.keysym.sym == SDLK_a ||
                    event.key.keysym.sym == SDLK_LEFT) {
                        input->setInputDown(Inputs::Left, true);
                    } else if (
                    event.key.keysym.sym == SDLK_d ||
                    event.key.keysym.sym == SDLK_RIGHT) {
                        input->setInputDown(Inputs::Right, true);
                    } else if (event.key.keysym.sym == SDLK_SPACE) {
                        input->setInputDown(Inputs::Start, true);
                    }
                } else if (event.type == SDL_KEYUP) {
                    if (event.key.keysym.sym == SDLK_ESCAPE) {
                        running = false;
                    } else if (
                    event.key.keysym.sym == SDLK_a ||
                    event.key.keysym.sym == SDLK_LEFT) {
                        input->setInputDown(Inputs::Left, false);
                    } else if (
                    event.key.keysym.sym == SDLK_d ||
                    event.key.keysym.sym == SDLK_RIGHT) {
                        input->setInputDown(Inputs::Right, false);
                    } else if (event.key.keysym.sym == SDLK_SPACE) {
                        input->setInputDown(Inputs::Start, false);
                    }
                }
            }

            SDL_SetRenderDrawColor(renderer, 0x0, 0x0, 0x0, 0xFF);
			SDL_RenderClear(renderer);

            level->update(TARGET_S);
            entities->updateAll(TARGET_S);
            entities->renderAll(renderer);

            Uint32 ticksPassed = frameCapTimer.get_ticks();
            if (ticksPassed < TARGET_MS) {
                SDL_Delay(TARGET_MS - ticksPassed);
            }
            frameCapTimer.restart();

            SDL_RenderPresent(renderer);
        }

        //Cleanup
        level->shutdown();
        entities->shutdown();
        resources->shutdown();
        input->shutdown();
        SDL_DestroyRenderer(renderer);
        SDL_DestroyWindow(window);
        TTF_Quit();
        SDL_Quit();

        return 0;
    }
}