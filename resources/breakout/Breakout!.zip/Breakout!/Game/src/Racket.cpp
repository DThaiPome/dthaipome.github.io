#include "Racket.hpp"
#include "Inputs.hpp"
#include "Constants.hpp"
#include "LevelManager.hpp"

Racket::Racket() : GameObject() {}

Racket::~Racket() {}

void Racket::init() {
    this->width = 100;
    this->height = 15;
    this->position = Vector3D((WINDOW_WIDTH / 2) - (this->width / 2), 650);

    this->rect.x = this->position.x;
    this->rect.y = this->position.y;
    this->rect.w = this->width;
    this->rect.h = this->height;

    this->input = InputManager::getInstance();
}

void Racket::update(float deltaTime) {
    if (LevelManager::getInstance()->isGameActive()) {
        // Move
        Vector3D dPos = Vector3D(0, 0);
        if (this->input->getInputDown(Inputs::Left)) {
            dPos += Vector3D(-1, 0);
        }
        if (this->input->getInputDown(Inputs::Right)) {
            dPos += Vector3D(1, 0);
        }
        this->position += (dPos * PADDLE_SPEED * deltaTime);

        // Snap to edge of window
        float left = this->position.x;
        float right = left + this->width;
        if (left <= 0) {
            this->position.x = 0;
        } else if (right >= WINDOW_WIDTH) {
            this->position.x = WINDOW_WIDTH - this->width;
        }
    }
}

void Racket::render(SDL_Renderer* ren) {
    this->rect.x = this->position.x;

    SDL_SetRenderDrawColor(ren, 0xFF, 0xFF, 0xFF, 0xFF);
    SDL_RenderFillRect(ren, &(this->rect));
}