
#if defined(LINUX) || defined(MINGW)
    #include <SDL2/SDL.h>
#else // This works for Mac
    #include <SDL.h>
#endif

// I recommend a map for filling in the resource manager
#include <map>
#include <string>
#include <memory>
#include <iterator>
#include <iostream>
#include <fstream>
#include <exception>
#include "Constants.hpp"

#include "ResourceManager.hpp"

ResourceManager* ResourceManager::instance = nullptr;

ResourceManager::ResourceManager(){
}


ResourceManager::~ResourceManager(){
	if (this->initialized) {
		this->shutdown();
	}

	if (instance) {
		delete instance;
	}
}

ResourceManager* ResourceManager::getInstance() {
	if (!instance) {
		instance = new ResourceManager();
	}
	return instance;
}

void ResourceManager::init() {
	this->levelCount = 0;
	this->initialized = true;
}

Sprite* ResourceManager::loadSprite(std::string imagePath, int frames, int width, int height, SDL_Renderer* ren) {
	if (this->initialized) {
		if (this->sprites[imagePath]) {
			return this->sprites[imagePath];
		} else {
			SDL_Surface* spriteSheet = SDL_LoadBMP(imagePath.c_str());
			if (spriteSheet==NULL) {
				std::string msg = "Loading sprite at " + imagePath + " failed.";
				SDL_Log("%s", msg.c_str());
				return nullptr;
			} else {
				Sprite* sprite = new Sprite(spriteSheet, frames, width, height, ren);
				this->sprites[imagePath] = sprite;
				return sprite;
			}
		}
	}
	return nullptr;
}

TTF_Font* ResourceManager::loadFont(std::string fontPath, unsigned int size) {
	if (this->initialized) {
		std::string fontKey = fontPath + std::to_string(size);
		if (this->fonts[fontKey]) {
			return this->fonts[fontKey];
		} else {
			TTF_Font* font = TTF_OpenFont(fontPath.c_str(), size);
			if (font==NULL) {
				std::string msg = "Loading font at " + fontPath + " failed.";
				SDL_Log("%s", msg.c_str());
				return nullptr;
			}
			this->fonts[fontKey] = font;
			return font;
		}
	}
	return nullptr;
}

Mix_Chunk* ResourceManager::loadSound(std::string soundPath) {
	if (this->initialized) {
		if (this->sounds[soundPath]) {
			return this->sounds[soundPath];
		} else {
			Mix_Chunk* sound = Mix_LoadWAV(soundPath.c_str());
			if (sound==NULL) {
				std::string msg = "Loading sound at " + soundPath + " failed.";
				SDL_Log("%s", msg.c_str());
				return nullptr;
			}
			this->sounds[soundPath] = sound;
			return sound;
		}
	}
	return nullptr;
}

Mix_Music* ResourceManager::loadMusic(std::string musicPath) {
	if (this->initialized) {
		if (this->musics[musicPath]) {
			return this->musics[musicPath];
		} else {
			Mix_Music* music = Mix_LoadMUS(musicPath.c_str());
			if (music==NULL) {
				std::string msg = "Loading music at " + musicPath + " failed.";
				SDL_Log("%s", msg.c_str());
				return nullptr;
			}
			this->musics[musicPath] = music;
			return music;
		}
	}
	return nullptr;
}

// Load all files in the format [levelX.txt] starting with 1
void ResourceManager::loadLevelsFrom(std::string folderPath) {
	std::string filePrefix = folderPath + "level";
	std::string fileSuffix = ".txt";
	std::vector<std::vector<std::string>> lineSet;

	int index = 1;
	bool badFileNotFound = true;
	while(badFileNotFound) {
		std::string filePath = filePrefix + std::to_string(index) + fileSuffix;
		std::ifstream file(filePath.c_str());
		if (!(file.is_open())) {
			SDL_Log("%s", msg.c_str());
			badFileNotFound = false;
			break;
		}
		std::vector<std::string> lines;
		std::string line;
		while(std::getline(file, line)) {
			lines.push_back(line);
		}
		lineSet.push_back(lines);
		index++;
	}

	// Convert strings to level
	for(auto it = lineSet.begin(); it != lineSet.end(); it++) {
		unsigned int width = 0;
		unsigned int height = 0;
		const std::vector<std::string> & lineVector = *it;
		try {
			width = std::stoi(lineVector[0]);
			height = std::stoi(lineVector[1]);
		} catch(...) {
			SDL_Log("Loading level failed: bad width/height format");
			continue;
		}

		bool** data = this->initData(width, height);
		try {
			for(size_t i = 0; i < height; i++) {
				const std::string & lineStr = lineVector[i+2];
				for(int j = 0; j < width; j++) {
					const char & c = lineStr.at(j);
					if (c == YES_BRICK_CHAR) {
						data[i][j] = true;
					} else if (c == NO_BRICK_CHAR) {
						data[i][j] = false;
					} else {
						throw 0; // Invalid character, toss everything
					}
				}
			}
		} catch(...) {
			SDL_Log("Loading level failed: bad brick location character");
			this->deleteData(data, height);
			continue;
		}

		LevelData finalData = { width, height, data };
		this->levelData.push_back(finalData); 
		this->levelCount++;
	}
}

const LevelData & ResourceManager::loadLevel(unsigned int levelIndex) {
	if (levelIndex < this->levelCount) {
		return this->levelData[levelIndex];
	}
	return this->levelData[0];
}

unsigned int ResourceManager::getLevelCount() {
	return this->levelCount;
}

void ResourceManager::shutdown() {
	if (this->initialized) {
		for(auto it = this->sprites.begin(); it != this->sprites.end(); it++) {
			delete it->second;
		}
		this->sprites.clear();
		for(auto it = this->fonts.begin(); it != this->fonts.end(); it++) {
			TTF_CloseFont(it->second);
		}
		this->fonts.clear();
		for(auto it = this->sounds.begin(); it != this->sounds.end(); it++) {
			Mix_FreeChunk(it->second);
		}
		this->sounds.clear();
		for(auto it = this->musics.begin(); it != this->musics.end(); it++) {
			Mix_FreeMusic(it->second);
		}
		this->sounds.clear();
		for(auto it = this->levelData.begin(); it != this->levelData.end(); it++) {
			unsigned int rows = it->height;
			bool** data = it->data;
			this->deleteData(data, rows);
		}
		this->levelData.clear();
		this->levelCount = 0;
	}
	this->initialized = false;
}

bool** ResourceManager::initData(unsigned int width, unsigned int height) {
	bool** data = new bool*[height];
	for(int i = 0; i < height; i++) {
		data[i] = new bool[width];
	}
	return data;
}

void ResourceManager::deleteData(bool** data, unsigned int height) {
	for(int i = 0; i < height; i++) {
		delete[] data[i];
	}
	delete[] data;
}

bool ResourceManager::loadLanguage(std::string languagePath) {
	std::ifstream file(languagePath);
	if (!(file.is_open())) {
		return false;
	}
	std::vector<std::string> lines;
	std::string line;
	while (std::getline(file, line)) {
		lines.push_back(line);
	}
	// Parse lines
	try {
		size_t lineCount = lines.size();
		for(int i = 0; i < lineCount - 1; i += 2) {
			std::string id = lines[i];
			std::string text = lines[i+1];
			this->language[id] = text;	
		}
	} catch(...) {
		SDL_Log("Loading language from %s failed: bad format", languagePath.c_str());
		return false;
	}
	return true;
}

const std::string & ResourceManager::getPhrase(std::string id) {
	return this->language[id];
}

void ResourceManager::setGlobalRenderer(SDL_Renderer* ren) {
	this->globalRenderer = ren;
}

SDL_Renderer* ResourceManager::getGlobalRenderer() {
	return this->globalRenderer;
}